package pl.edu.pjatk.MPR_2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mpr2Application {

	public static void main(String[] args) {
		SpringApplication.run(Mpr2Application.class, args);
	}

}
